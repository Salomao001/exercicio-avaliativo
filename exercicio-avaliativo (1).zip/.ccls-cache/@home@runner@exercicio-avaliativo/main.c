#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_USUARIOS 1000

typedef struct {
  int id;
  char nome[50];
  char email[50];
  char sexo[15];
  char endereco[100];
  double altura;
  int vacina;
} Usuario;

// Declaração das funções
void cadastrarUsuario(Usuario usuarios[], int *numUsuarios);

int main() {
  Usuario usuarios[MAX_USUARIOS];
  int numUsuarios = 0;
  char opcao;

  do {
    printf("Escolha a opção: ");
    scanf(" %c", &opcao);

    switch (opcao) {
    case '1':
      cadastrarUsuario(usuarios, &numUsuarios);
      break;
    case '0':
      printf("Saindo...\n");
      break;
    default:
      printf("Opcao invalida!\n");
    }

    printf("\n");
  } while (opcao != '0');

  return 0;
}
void cadastrarUsuario(Usuario usuarios[], int *qtdUsuarios) {
  // Verifica se ainda é possível cadastrar mais usuários
  if (*qtdUsuarios >= 1000) {
    printf("Limite de usuários cadastrados atingido.\n");
    return;
  }

  Usuario novoUsuario;

  // Preenche os dados do novo usuário
  printf("Preencha os dados do novo usuário:\n");
  novoUsuario.id = rand() % 1000 + 1;
  printf("ID: %d\n", novoUsuario.id);
  printf("Nome completo: ");
  fgets(novoUsuario.nome, sizeof(novoUsuario.nome), stdin);
  do {
    printf("Email: ");
    scanf("%s", &novoUsuario.email);
  } while (strstr(novoUsuario.email, "@") == NULL);
  printf("Sexo (Feminino/Masculino/Indiferente): ");
  fgets(novoUsuario.sexo, sizeof(novoUsuario.sexo), stdin);
  printf("Endereço: ");
  fgets(novoUsuario.endereco, sizeof(novoUsuario.endereco), stdin);
  do {
    printf("Altura (m): ");
    scanf("%lf", &novoUsuario.altura);
  } while (novoUsuario.altura < 1 || novoUsuario.altura > 2);
  do {
    printf("Já tomou a vacina? (1 - Sim / 0 - Não): ");
    scanf("%d", &novoUsuario.vacina);
  } while (novoUsuario.vacina != 0 && novoUsuario.vacina != 1);
  getchar(); // Limpa o buffer do teclado após a leitura da vacina

  // Adiciona o novo usuário ao vetor
  usuarios[*qtdUsuarios] = novoUsuario;
  (*qtdUsuarios)++;

  printf("Usuário cadastrado com sucesso!\n");
}
